#include "LibraryItemController.h"

void LibraryItemController::saveLibraryItem(const LibraryItem& item)
{

}

LibraryItem& LibraryItemController::getLibraryItem(const size_t id)
{

}

void LibraryItemController::updateLibraryItem(const size_t id)
{

}

void LibraryItemController::deleteLibraryItem(const size_t id)
{

}

Book* LibraryItemController::getAllBooks()
{

}

Series* LibraryItemController::getAllSeries()
{

}

LibraryItem** LibraryItemController::getAll()
{

}

void LibraryItemController::printLibraryitemInfo(const String issnOrIsbnNumber)
{

}

LibraryItem** LibraryItemController::findLibraryItems(const String option, const String optionValue)
{

}

LibraryItem** LibraryItemController::findLibraryItems(const String option, const String optionValue, const Order order)
{

}

Book* LibraryItemController::findBooks(const String option, const String optionValue)
{

}

Book* LibraryItemController::findBooks(const String option, const String optionValue, const Order order)
{

}

Series* LibraryItemController::findSeries(const String option, const String optionValue)
{

}

Series* LibraryItemController::findSeries(const String option, const String optionValue, const Order order)
{

}